//
//  resetPasswordScreen.swift
//  SWE
//
//  Created by Noura alsulayfih on 28/11/2021.
//

import UIKit
import Firebase

class resetPasswordScreen: UIViewController {

    @IBOutlet var resetbutton: UIButton!
    @IBOutlet var errorLabel: UILabel!
    @IBOutlet var userName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resetbutton.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        resetbutton.layer.cornerRadius = 10
    }
    @IBAction func resetButton(_ sender: Any) {
        Auth.auth().sendPasswordReset(withEmail: userName.text!) { error in
            guard error == nil else{
                self.errorLabel.alpha = 1
                return
            }
            self.errorLabel.alpha = 0
            let alert = UIAlertController(title: "تم الارسال", message: "الرجاء التحقق من بريدك الالكتروني", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "تأكيد", style: .default) { Action in
                self.dismiss(animated: true, completion: nil)
            }
            alert.addAction(alertAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
    @IBAction func backButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}

//Aljowharah.aldawood@gmail.com

//S39201282@gmail.com-> student
//F23456789@gmail.com -> faculty member
//E23456789@gmail.com -> employee
