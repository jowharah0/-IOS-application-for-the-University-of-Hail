//
//  contactUniversity.swift
//  SWE
//
//  Created by Noura alsulayfih on 29/11/2021.
//

import UIKit
import MessageUI

class contactUniversity: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func email1(_ sender: Any) {
        if !MFMailComposeViewController.canSendMail() {
            print("Mail services are not available")
            return
        }
        let composeVC = MFMailComposeViewController()
        composeVC.mailComposeDelegate = self

        composeVC.setToRecipients(["test@gmail.com"])
        composeVC.setSubject("Report a Bug or Request a Feature")


        self.parent?.present(composeVC, animated: true, completion: nil)
    }
    
    @IBAction func facebook1(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://facebook.com")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func twitter1(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://www.twitter.com/wixvii")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func email(_ sender: Any) {
        if !MFMailComposeViewController.canSendMail() {
            print("Mail services are not available")
            return
        }
        let composeVC = MFMailComposeViewController()
        composeVC.mailComposeDelegate = self
        composeVC.setToRecipients(["test@gmail.com"])
        composeVC.setSubject("Report a Bug or Request a Feature")
        self.parent?.present(composeVC, animated: true, completion: nil)
    }
    
    @IBAction func facebook(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://facebook.com")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
        
    }
    
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func twitter(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://www.twitter.com/wixvii")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
    }
    
}

extension contactUniversity: MFMailComposeViewControllerDelegate{
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {

    controller.dismiss(animated: true, completion: nil)

}
}
