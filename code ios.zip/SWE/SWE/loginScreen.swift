//
//  loginViewController.swift
//  SWE
//
//  Created by Noura alsulayfih on 28/11/2021.
//

import UIKit
import Firebase

class loginScreen: UIViewController {
    
    @IBOutlet var userName: UITextField!
    @IBOutlet var password: UITextField!
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var errorLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        userName.layer.cornerRadius = 10
        password.layer.cornerRadius = 10
        loginButton.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        loginButton.layer.cornerRadius = 10
    }
    
    private func goToHome(identifier:String){
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        var vc = UIViewController()
        switch identifier {
        case "studentHome":
            let goToVC = storyboard.instantiateViewController(identifier: "studentHome") as! mainScreen
            goToVC.user = userName.text
            vc = goToVC
            break
        case "facultyMemberScreen":
            let goToVC = storyboard.instantiateViewController(identifier: "facultyMemberScreen") as! facultyMemberScreen
            goToVC.user = userName.text
            vc = goToVC
            break
        case "employeeScreen":
            let goToVC = storyboard.instantiateViewController(identifier: "employeeScreen") as! employeeScreen
            goToVC.user = userName.text
            vc = goToVC
            break
        default:
            print("unknown")
        }
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func loginButton(_ sender: Any) {
        if userName.text == nil || userName.text == "" || userName.text == " "  || password.text == nil || password.text == "" || password.text == " "{
            errorLabel.alpha = 1
        }else{
            errorLabel.alpha = 0
            Auth.auth().signIn(withEmail: userName.text!, password: password.text!) { authResult, error in
                
                guard error == nil else{
                    self.errorLabel.alpha = 1
                    return
                }
                let authUser = self.userName.text!.prefix(1)
                print(authUser)
                if authUser == "S" || authUser == "s"{
                    self.goToHome(identifier: "studentHome")
                }else if authUser == "E" || authUser == "e"{
                    self.goToHome(identifier: "employeeScreen")
                }else if authUser == "F" || authUser == "f"{
                    self.goToHome(identifier: "facultyMemberScreen")
                }else{
                    self.errorLabel.alpha = 1
                }
            }
        }
        

    }
}
