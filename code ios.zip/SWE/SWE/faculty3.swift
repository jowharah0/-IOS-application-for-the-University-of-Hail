//
//  faculty3.swift
//  SWE
//
//  Created by Noura alsulayfih on 29/11/2021.
//

import UIKit

class faculty3: UIViewController {
    
    var user:String?
    
    @IBOutlet var button1: UIButton!
    @IBOutlet var userName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        userName.text = user
        
        button1.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button1.layer.cornerRadius = 10
        button1.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
    }
    

    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
