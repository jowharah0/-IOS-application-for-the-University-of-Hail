//
//  student3.swift
//  SWE
//
//  Created by Noura alsulayfih on 29/11/2021.
//

import UIKit

class student3: UIViewController {
    
    @IBOutlet var userName: UILabel!
    
    var user:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        userName.text = user
    }
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
