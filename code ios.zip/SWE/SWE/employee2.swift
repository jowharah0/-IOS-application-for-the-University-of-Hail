//
//  employee2.swift
//  SWE
//
//  Created by Noura alsulayfih on 29/11/2021.
//

import UIKit

class employee2: UIViewController {

    @IBOutlet var button1: UIButton!
    @IBOutlet var button2: UIButton!
    @IBOutlet var button3: UIButton!
    @IBOutlet var userName: UILabel!
    
    var user:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        userName.text = user
        button1.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button1.layer.cornerRadius = 10
        button1.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        
        button2.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button2.layer.cornerRadius = 10
        button2.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        
        button3.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button3.layer.cornerRadius = 10
        button3.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
    }

    @IBAction func bavk(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
