//
//  guestScreen.swift
//  SWE
//
//  Created by Noura alsulayfih on 29/11/2021.
//

import UIKit

class guestScreen: UIViewController {

    @IBOutlet var view1: UIView!
    @IBOutlet var view2: UIView!
    @IBOutlet var view3: UIView!
    @IBOutlet var view4: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view1.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        
        view2.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        
        view3.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        view3.layer.cornerRadius = 10
        
        view4.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        view4.layer.cornerRadius = 10
    }
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
