//
//  contactSupport.swift
//  SWE
//
//  Created by Noura alsulayfih on 28/11/2021.
//

import UIKit
import MobileCoreServices
import UniformTypeIdentifiers
import Firebase
import MessageUI

class contactSupport: UIViewController {
    
    @IBOutlet var name: UITextField!
    @IBOutlet var email: UITextField!
    @IBOutlet var phone: UITextField!
    @IBOutlet var problem: UITextView!
    @IBOutlet var addFile: UIButton!
    @IBOutlet var sendButton: UIButton!
    @IBOutlet var cancelButton: UIButton!
    @IBOutlet var nameError: UILabel!
    @IBOutlet var emailError: UILabel!
    @IBOutlet var contactError: UILabel!
    @IBOutlet var problemError: UILabel!
    
    var ref = Database.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sendButton.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        sendButton.layer.cornerRadius = 10
        
        cancelButton.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        cancelButton.layer.cornerRadius = 10
        
        addFile.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        addFile.layer.cornerRadius = 10
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func sendButton(_ sender: Any) {
        guard ((name.text == nil || name.text == "" || name.text == " ") && (email.text == nil || email.text == "" || email.text == " ") && (phone.text == nil || phone.text == "" || phone.text == " ") && (problem.text == nil || problem.text == "" || problem.text == " ")) else{
            
            if name.text == nil || name.text == "" || name.text == " "{
                nameError.alpha = 1
            }else{
                nameError.alpha = 0
            }
            
            if email.text == nil || email.text == "" || email.text == " " {
                emailError.alpha = 1
            }else{
                emailError.alpha = 0
            }
            
            if phone.text == nil || phone.text == "" || phone.text == " "{
                contactError.alpha = 1
            }else{
                contactError.alpha = 0
            }
            
            if problem.text == nil || problem.text == "" || problem.text == " " {
                problemError.alpha = 1
            }else{
                problemError.alpha = 0
            }
            
            if ((name.text != nil && name.text != "" && name.text != " ") && (email.text != nil && email.text != "" && email.text != " ") && (phone.text != nil && phone.text != "" && phone.text != " ") && (problem.text != nil && problem.text != "" && problem.text != " ")) {
                print("send the request")
                self.nameError.alpha = 0
                self.emailError.alpha = 0
                self.contactError.alpha = 0
                self.problemError.alpha = 0
                self.ref.child("Support").childByAutoId().setValue(["name":name.text!,"email":email.text!,"phone":phone.text!,"problem":problem.text!])
                let alert = UIAlertController(title: "تم الارسال", message:"تم ارسال طلبك بنجاح، سوف يتم التواصل معك قريبا", preferredStyle: .alert)
                let alertAction = UIAlertAction(title: "تأكيد", style: .default) { Action in
                    self.dismiss(animated: true, completion: nil)
                }
                alert.addAction(alertAction)
                self.present(alert, animated: true, completion: nil)
            }
            return
        }
        nameError.alpha = 1
        emailError.alpha = 1
        contactError.alpha = 1
        problemError.alpha = 1
    }
    @IBAction func email(_ sender: Any) {
        if !MFMailComposeViewController.canSendMail() {
            print("Mail services are not available")
            return
        }
        let composeVC = MFMailComposeViewController()
        composeVC.mailComposeDelegate = self
        composeVC.setToRecipients(["test@gmail.com"])
        composeVC.setSubject("Report a Bug or Request a Feature")
        self.parent?.present(composeVC, animated: true, completion: nil)
    }
    @IBAction func facebook(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://facebook.com")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func twitter(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://www.twitter.com/wixvii")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
    }
    
    
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addFileButton(_ sender: Any) {
        let types = UTType.types(tag: "json",
                                 tagClass: UTTagClass.filenameExtension,
                                 conformingTo: nil)
        let documentPickerController = UIDocumentPickerViewController(
            forOpeningContentTypes: types)
        documentPickerController.delegate = self
        self.present(documentPickerController, animated: true, completion: nil)
    }
    
}

extension contactSupport: UIDocumentPickerDelegate{
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let myURL = urls.first else {
            return
        }
        print("import result : \(myURL)")
    }
}

extension contactSupport: MFMailComposeViewControllerDelegate{
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {

    controller.dismiss(animated: true, completion: nil)

}
}


//s44002280@gmail.com
