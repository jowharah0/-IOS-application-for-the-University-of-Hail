//
//  homeScreen.swift
//  SWE
//
//  Created by Noura alsulayfih on 28/11/2021.
//

import UIKit

class homeScreen: UIViewController {

    @IBOutlet var loginButton: UIButton!
    @IBOutlet var asGuest: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loginButton.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        asGuest.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        loginButton.layer.cornerRadius = 10
        asGuest.layer.cornerRadius = 10
    }


}

