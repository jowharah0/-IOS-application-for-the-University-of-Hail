//
//  mainScreen.swift
//  SWE
//
//  Created by Noura alsulayfih on 28/11/2021.
//

import UIKit
import MessageUI
import Firebase

class mainScreen: UIViewController {

    @IBOutlet var language: UIButton!
    @IBOutlet var menu: UIButton!
    @IBOutlet var userName: UILabel!
    @IBOutlet var button1: UIButton!
    @IBOutlet var button2: UIButton!
    @IBOutlet var button3: UIButton!
    @IBOutlet var latestNews: UIView!
    @IBOutlet var button4: UIButton!
    
    var user:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        userName.text = user
        button1.titleLabel?.textAlignment = .center
        button1.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        button2.titleLabel?.textAlignment = .center
        button2.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        button3.titleLabel?.textAlignment = .center
        button3.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        button4.titleLabel?.textAlignment = .center
        button4.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        button1.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button2.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button3.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button4.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button1.layer.cornerRadius = 10
        button2.layer.cornerRadius = 10
        button3.layer.cornerRadius = 10
        button4.layer.cornerRadius = 10
        latestNews.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        latestNews.layer.cornerRadius = 2
    }
    
    private func goToLoginScreen(){
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "homeScreen") as! homeScreen
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func email(_ sender: Any) {
        if !MFMailComposeViewController.canSendMail() {
            print("Mail services are not available")
            return
        }
        let composeVC = MFMailComposeViewController()
        composeVC.mailComposeDelegate = self
        composeVC.setToRecipients(["test@gmail.com"])
        composeVC.setSubject("Report a Bug or Request a Feature")
        self.parent?.present(composeVC, animated: true, completion: nil)
    }
    @IBAction func facebook(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://facebook.com")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
    }
    @IBAction func twitter(_ sender: Any) {
        let twUrl = URL(string: "twitter://user?screen_name=wixvii")!
        let twUrlWeb = URL(string: "https://www.twitter.com/wixvii")!
        if UIApplication.shared.canOpenURL(twUrl){
           UIApplication.shared.open(twUrl, options: [:],completionHandler: nil)
        }else{
           UIApplication.shared.open(twUrlWeb, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func showMenu(_ sender: Any) {
        //logout
        do {
            try Auth.auth().signOut()
            let userDefault = UserDefaults.standard
            userDefault.setValue(false, forKey: "isUserSignedIn")
            goToLoginScreen()
        } catch _ {
            print("error")
        }
    }

    @IBAction func button1(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "student1") as! student1
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func button2(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "student2") as! student2
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func button3(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "student3") as! student3
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func button4(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "student4") as! student4
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func chnageLanguage(_ sender: Any) {
        
    }
}

extension mainScreen: MFMailComposeViewControllerDelegate{
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {

    controller.dismiss(animated: true, completion: nil)

}
}
