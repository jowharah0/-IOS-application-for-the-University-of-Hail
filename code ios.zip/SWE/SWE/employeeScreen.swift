//
//  employeeScreen.swift
//  SWE
//
//  Created by Noura alsulayfih on 28/11/2021.
//

import UIKit
import Firebase

class employeeScreen: UIViewController {
    
    @IBOutlet var userName: UILabel!
    @IBOutlet var button1: UIButton!
    @IBOutlet var button2: UIButton!
    @IBOutlet var button3: UIButton!
    @IBOutlet var button4: UIButton!
    
    var user:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        userName.text = user
        button1.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button1.layer.cornerRadius = 10
        button1.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        
        button2.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button2.layer.cornerRadius = 10
        button2.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        
        button3.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button3.layer.cornerRadius = 10
        button3.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
        
        button4.backgroundColor = UIColor(red: 0.211, green: 0.221, blue: 0.454, alpha: 1)
        button4.layer.cornerRadius = 10
        button4.setTitleColor(UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1), for: .normal)
    }
    
    private func goToLoginScreen(){
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "homeScreen") as! homeScreen
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func button1(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "employee1") as! employee1
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func button2(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "employee2") as! employee2
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func button3(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "employee3") as! employee3
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func button4(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "employee4") as! employee4
        vc.user = user
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func logout(_ sender: Any) {
        //logout
        do {
            try Auth.auth().signOut()
            let userDefault = UserDefaults.standard
            userDefault.setValue(false, forKey: "isUserSignedIn")
            goToLoginScreen()
        } catch _ {
            print("error")
        }
    }
    
}
