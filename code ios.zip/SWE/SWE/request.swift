//
//  request.swift
//  SWE
//
//  Created by Noura alsulayfih on 04/12/2021.
//

import UIKit
import Firebase

class request: UIViewController {

    @IBOutlet var userName: UILabel!
    @IBOutlet var nameError: UILabel!
    @IBOutlet var error2: UILabel!
    @IBOutlet var error3: UILabel!
    @IBOutlet var error4: UILabel!
    @IBOutlet var error5: UILabel!
    @IBOutlet var error6: UILabel!
    @IBOutlet var sendRequest: UIButton!
    @IBOutlet var cancelRequest: UIButton!
    @IBOutlet var text1: UITextField!
    @IBOutlet var text2: UITextField!
    @IBOutlet var text3: UITextField!
    @IBOutlet var text4: UITextField!
    @IBOutlet var text5: UITextField!
    @IBOutlet var text6: UITextField!
    
    var ref = Database.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        sendRequest.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        sendRequest.layer.cornerRadius = 10
        
        cancelRequest.backgroundColor = UIColor(red: 0.938, green: 0.848, blue: 0.498, alpha: 1)
        cancelRequest.layer.cornerRadius = 10
    }


    @IBAction func sendRequest(_ sender: Any) {
        guard ((text1.text == nil || text1.text == "" || text1.text == " ") && (text2.text == nil || text2.text == "" || text2.text == " ") && (text3.text == nil || text3.text == "" || text3.text == " ") && (text4.text == nil || text4.text == "" || text4.text == " ") && (text5.text == nil || text5.text == "" || text5.text == " ") && (text6.text == nil || text6.text == "" || text6.text == " ")) else{
            
            if text1.text == nil || text1.text == "" || text1.text == " "{
                nameError.alpha = 1
            }else{
                nameError.alpha = 0
            }
            
            if text2.text == nil || text2.text == "" || text2.text == " " {
                error2.alpha = 1
            }else{
                error2.alpha = 0
            }
            
            if text3.text == nil || text3.text == "" || text3.text == " "{
                error3.alpha = 1
            }else{
                error3.alpha = 0
            }
            
            if text4.text == nil || text4.text == "" || text4.text == " " {
                error4.alpha = 1
            }else{
                error4.alpha = 0
            }
            
            if text5.text == nil || text5.text == "" || text5.text == " " {
                error5.alpha = 1
            }else{
                error5.alpha = 0
            }
            
            if text6.text == nil || text6.text == "" || text6.text == " " {
                error6.alpha = 1
            }else{
                error6.alpha = 0
            }
            
            if ((text1.text != nil && text1.text != "" && text1.text != " ") && (text2.text != nil && text2.text != "" && text2.text != " ") && (text3.text != nil && text3.text != "" && text3.text != " ") && (text4.text != nil && text4.text != "" && text4.text != " ") && (text5.text != nil && text5.text != "" && text5.text != " ") && (text6.text != nil && text6.text != "" && text6.text != " ")) {
                print("send the request")
                self.nameError.alpha = 0
                self.error2.alpha = 0
                self.error3.alpha = 0
                self.error4.alpha = 0
                self.error5.alpha = 0
                self.error6.alpha = 0
                self.ref.child("Request").childByAutoId().setValue(["field1":text1.text!,"field2":text2.text!,"field3":text3.text!,"field4":text4.text!,"field5":text5.text!, "field6":text6.text!])
                let alert = UIAlertController(title: "تم الارسال", message:"تم ارسال طلب الندوة بنجاح", preferredStyle: .alert)
                let alertAction = UIAlertAction(title: "تأكيد", style: .default) { Action in
                    self.dismiss(animated: true, completion: nil)
                }
                alert.addAction(alertAction)
                self.present(alert, animated: true, completion: nil)
            }
            return
        }
        nameError.alpha = 1
        error2.alpha = 1
        error3.alpha = 1
        error4.alpha = 1
        error5.alpha = 1
        error6.alpha = 1

    }
    
    private func goToLoginScreen(){
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "homeScreen") as! homeScreen
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func logout(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            let userDefault = UserDefaults.standard
            userDefault.setValue(false, forKey: "isUserSignedIn")
            goToLoginScreen()
        } catch _ {
            print("error")
        }
    }
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func cancelRequest(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
